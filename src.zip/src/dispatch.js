import './App.css';
import { Component } from 'react';
import Home from './view/home';
import Nav from './view/nav.js';

//model
export default class Dispatch extends Component {
  constructor(props){
    super(props);
  
  }


  render(){
    let app = this.props.app;
  return (
    <div >
       <Nav app={app}/> 
     <Home app={app}/> 
    </div>
  )}
}