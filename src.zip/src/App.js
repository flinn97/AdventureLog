import './App.css';
import { Component } from 'react';

import picservice from './services/picservice';
import Auth from './services/auth';
import Factory from './models/myComponents';
import Opps from './models/operationsFactory';
import Dispatch from './dispatch';
import ComponentListInterface from './componentListNPM/componentListInterface';

//model
export default class App extends Component {
  constructor(props){
    super(props);
        this.handleChange=this.handleChange.bind(this);
        this.dispatch=this.dispatch.bind(this);

    this.state={
      user: undefined,
      componentListInterface: new ComponentListInterface(this.dispatch),
      componentList: undefined,
      pic: null,
      switchcase: "monsters",
      recentpics : [],
      
      i: 2,
      operate: undefined,
      operation: "cleanJsonPrepare",
      object: undefined,
      currentComponent: undefined,
      backend: false,
      backendUpdate: undefined,
      picChange:false
    }
  }

  async componentDidUpdate(props, state){
    if(this.state.picChange){
      this.setState({operate:"update", operation:"cleanPrepare", object: this.state.pic, picChange:false, })
    }
    if(this.state.operate!==undefined){
      let operate = this.state.operate;
      let operation= this.state.operation;
      let object= this.state.object;
      await this.setState({operate:undefined, object:undefined, operation:"cleanJsonPrepare"});

      debugger
      let currentComponent = await this.state.componentListInterface.getOperationsFactory().operationsFactoryListener({operate: operate, object:object, operation: operation});
      
      console.log(currentComponent);
      let key = await this.state.componentListInterface.getOperationsFactory().getSplice(operate);
      if(currentComponent!==undefined){
        this.setState({currentComponent: currentComponent[key][0]});
      }
    }

    
    
    

  }

  async dispatch(obj){

    await this.setState(obj)
}

handleChange = (event) => {
    const { name, value } = event.target
    this.setState({
        [name]: value,
    })
}

  async componentDidMount(){
    
    if(this.state.componentListInterface && this.state.componentList===undefined){
        let componentList= await this.state.componentListInterface.createComponentList();
        await this.setState({
          componentList:componentList
        })
        
        let user = await Auth.getuser(componentList);
        await this.setState({
          user: user
        })
        let pic =picservice.randomizepics(user.components, "monsters");
        this.setState({
          pic: pic,
          // recentpics: picservice.savepic(this.state, pic)
        })
        debugger
    }
   
    
  }

  //view
  render(){
  return (
    <div >
      <Dispatch app={{run:this.run, state:this.state, handlechange:this.handleChange, dispatch:this.dispatch, factory:this.factory}} />
    </div>
  )}
}