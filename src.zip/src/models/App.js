import React, { Component } from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
//uploade above stuff from npm.
import "./App.css";
import moment from 'moment';
import Dispatch from './dispatch';
import styleService from './services/styleService';
import authService from './services/auth.service';
import Factory from './models/factory';
import Opps from './model/operationsFactory';
//nav bar helps to navigate from page to page with authorizations to login or sign up etc. 
class App extends Component {
    constructor(props) {
        super(props);
        this.register=this.register.bind(this);
        this.handleChange=this.handleChange.bind(this);
        this.stateHandleChange=this.stateHandleChange.bind(this);
        this.prepareArray=this.prepareArray.bind(this);
        this.dispatch=this.dispatch.bind(this);
        this.run=this.run.bind(this);
        this.prepare=this.prepare.bind(this);
        this.prepareRun=this.prepareRun.bind(this);
        this.cleanPrepareRun=this.cleanPrepareRun.bind(this);
        this.cleanPrepare=this.cleanPrepare.bind(this);
        this.factory= new Factory();
        this.state = {
            styles: styleService.getstyles(),
            currentuser: undefined,   
            myswitch: "dash",
            appointments:{},
            today: moment().format('dddd').toString(),
            currentstudent: undefined,
            factory: this.factory,
            componentUpdate:{
                add:[],
                update:[],
                del:[]
            },
            switch:this.factory.getComponent("switch").getJson(),
            ...this.factory.getComponent("toState").getJson()
        };
    }
    async dispatch(obj){

        await this.setState(obj)
    }
    async prepare(obj){
        let prep = {...this.state.componentUpdate};
        let preparation = this.prepareArray(obj);
        for(const key in prep){
            if(preparation[key].length!==0){
                prep[key]=[...prep[key], ...preparation[key]];
            }
        }
        await this.setState({componentUpdate:prep, prepared: true});  
    }
    async cleanPrepare(obj){
        debugger
        let prep = this.state.componentUpdate;
        prep = this.prepareArray(obj);
        this.setState({componentUpdate:prep, prepared: true})
    }
    async prepareRun(obj){
        debugger
        await this.prepare(obj);
        this.run(); 
    }
    async cleanPrepareRun(obj){
        debugger
        await this.cleanPrepare(obj);
        this.run(); 
    }
    async run(option, clean){
        debugger
        if(option !==undefined && !option.pageX){
            let obj={
                clean: this.cleanPrepareRun,
                notClean: this.prepareRun
            }
            obj[clean===true?"clean":"notClean"](option);
        }
        await this.register();
        this.setState({
            componentUpdate:{add:[], update:[], del:[]},
            prepared:false
        })
    }

    prepareArray(obj){
        debugger
        let newObj={add:[],update:[],del:[]};
            for (const key in obj){
            let updateArr=[];
            let getSplice = this.getSplice(key);
            let i = obj[key];
            let bool =Number.isInteger(i)
            updateArr=bool?updateArr:[...i];
            if(bool){
                updateArr = [...newObj[getSplice]];
                for(let j=0; j<i; j++){
                    let component = key.substring(getSplice.length, key.length);
                    updateArr.push(this.factory.getComponent(component));
                    newObj[getSplice]=updateArr;
                } 
            }
            else{
                newObj[getSplice]=updateArr;
            }
    }
        return newObj
    }

    getSplice(word){
        if( word.includes("add")){
            word="add";
        }
        else if(word.includes("update")){
            word="update";
        }
        else if(word.includes("del")){
            word="del";
        }
        return word;
    }


    handleChange = (event) => {
        debugger
        const { name, value } = event.target;
        let myUpdate= this.state.componentUpdate.getJson();
        myUpdate[name]=value;
        this.register([{update: this.state.componentUpdate}]);
    }
    stateHandleChange = (event) => {
        const { name, value } = event.target
        this.setState({
            [name]: value,
        })
    }
    async register(){

        if(this.state.currentuser!==undefined && this.state.prepared){
           let operate= new Opps(this.state.currentuser.components, this.dispatch)
            await operate.register(this.state.componentUpdate);
            // authService.dispatch(operate.getBackArray(), this.state.email);
        }
    }
    
    render() {
        let app=this.state
        return (
            <div> 
            <Dispatch app={{dispatch:this.dispatch, handleChange:this.handleChange, state:app, prepare:this.prepare, run:this.run, cleanPrepare:this.cleanPrepare, cleanPrepareRun:this.cleanPrepareRun, prepareRun:this.prepareRun}}/>
            </div>
        );
    }
}
export default App;
/**
 * debugger
        if(arr.length){
            let obj = {currentuser:this.state.currentuser};
            let backEndSwitch= false;
            for(let i=0; i<arr.length; i++){
                switch(Object.keys(arr[i])[0]){
                    case "add":
                        arr[i].add = {...this.state.factory[arr[i].add?.type], ...this.state.componentUpdate, _id: (Math.floor(Date.now()+performance.now())).toString(), collection:this.state.email };
                        obj.currentuser.components.push(arr[i]);
                        backEndSwitch=true;
                        break;
                    case "del":
                        obj.currentuser.components.splice(i, 1);
                        backEndSwitch=true;
                        break;
                    case "update":
                        arr[i]= {...arr[i], ...this.state.componentUpdate};
                        backEndSwitch=true;
                        break;
                    case "noarray":
                        obj = {...arr[i].noarray}
                        break;
                }
                let todispatch = {...obj, componentUpdate: {}};
                this.setState(todispatch);
            }
            if(backEndSwitch){
                authService.changeData(arr, this.state.email);
            }
        }
        else{
            this.setState(arr); 
        }
        let toBackend={};
        let operationObject = Object.keys(obj)[0];
        if(operationObject ==="operations"){
            let userComponents= this.state.user.components;
            for(let i = 0; i<obj.operations; i++ ){
                let newObj = await obj.operations[i];
                userComponents=newObj.components;
                toBackend[newObj.backendOpp]=newObj.toBackend;
            }
            obj={currentuser: {components:userComponents}};
            // authService.changeData(toBackend);
        }
 */