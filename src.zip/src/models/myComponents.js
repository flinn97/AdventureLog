import BaseClass from "../componentListNPM/baseClass";
class BaseObject extends BaseClass{
    constructor(operationsFactory){
        super(operationsFactory);
    }
    json;
    starting={
        name:"",
        type: "",
        _id: "",
    }


}

class Pic extends BaseObject{
    constructor(operationsFactory){
        super(operationsFactory);
        this.keep=this.keep.bind(this);
    }
    json={
        ...this.starting,
        pics: "", 
        keep: 0,
    }
    async keep(){
        debugger
        this.json.keep= this.json.keep+1;
        await this.operationsFactory.jsonPrepareRun({["add"+"keep"+this.json.type]: {type: "add"+"keep"+this.json.type}})
    }
}

class User extends BaseObject{
    json={
        ...this.starting,
        email:"",
        type: "user"
    }
}



// class Factory {
//     factory ={
//         pic: new Pic(),
//         user: new User(),
//     }

//     getComponent(component, json){
//         let comp = this.factory[component];
//         comp = Object.assign(Object.create(Object.getPrototypeOf(comp)), comp);
//         comp.setJson({...comp.getJson(), ...json,});
//         return comp;
//     }
// }
export {User, Pic};
