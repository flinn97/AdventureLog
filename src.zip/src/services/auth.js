import Beholder from "../pics/beholder.webp";
import Dragon from "../pics/dragon.jpg"
import Kraken from "../pics/kraken169-2.jpg"
import Celestial from "../pics/celestial.jpg"
import Bongobongo from "../pics/bongobongo.webp"
import Mummy from "../pics/mummy.jpg"

class Auth{
    user(){
        
    }
    async getuser(componentList){
        let user = {};
        let components = [
            {name:"jared", email:"jared@gmail.com", type:"user", _id: "1"}, 
            {name: "mummy", pic: Mummy, type:"monsters",_id: "2"}, 
            {name: "bongobongo", pic: Bongobongo, type:"monsters",_id: "3"},
            {name: "celestial", pic: Celestial, type:"heroes", _id: "4"},
            {name: "dragon", pic: Dragon, type:"statblocks",_id: "5"}
        ];
        await componentList.addComponents(components);
        user.components=componentList.getComponents();
        return user;
    }
}
export default new Auth();