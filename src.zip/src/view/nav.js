import { Component } from 'react';
import "../App.css"


export default class Nav extends Component {
  constructor(props){
    super(props);
  }

  render(){
    let app = this.props.app
  return (
        <div style={{display:"flex", flexDirection:"column", backgroundColor:"white", position:"absolute", top:"0", left:"0",height:"100%", width:"300px", margin:"0 auto"}}>
    <div onClick={app.dispatch.bind(this, {switchcase: "keep"})} style={{cursor:"pointer", margin:"10px"}}>My Keep</div>
    <div onClick={app.dispatch.bind(this, {switchcase: "monsters"})}style={{cursor:"pointer", margin:"10px"}}>Monsters</div>
    <div onClick={app.dispatch.bind(this, {switchcase: "heroes"})}style={{cursor:"pointer", margin:"10px"}}>Heroes</div>
    <div onClick={app.dispatch.bind(this, {switchcase: "maps"})}style={{cursor:"pointer", margin:"10px"}}>Maps</div>
    <div onClick={app.dispatch.bind(this, {switchcase: "worlds"})}style={{cursor:"pointer", margin:"10px"}}>Worlds</div>
    <div onClick={app.dispatch.bind(this, {switchcase: "statblocks"})}style={{cursor:"pointer", margin:"10px"}}>Statblocks</div>
    </div>
  )}
}
//           {/* <Gallery state = {this.props.state} handlechange = {this.props.handlechange} /> */}