import { Component } from 'react';
import "../App.css"
// import Gallery from './pictures';
import left from '../pics/leftarrow.png'
import right from '../pics/rightarrow.png'
import Beholder from "../pics/beholder.webp";
import picservice from '../services/picservice';
import Feed from './feed';
import Keep from './keep';


export default class Home extends Component {
  constructor(props){
    super(props);
  }


  render(){
    let app=this.props.app;
    
  return (
        <div className="container">
          <img className="background" src={Beholder}/>
       <div className="subcontainer" >

          {app.state.switchcase==="keep"?(<Keep app={app} />):
          (<Feed app={app} />)}
           
       </div>
    </div>
  )}
}
//           {/* <Gallery state = {this.props.state} handlechange = {this.props.handlechange} /> */}