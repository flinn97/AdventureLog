import { Component } from 'react';
import "../App.css"
export default class Keep extends Component {
  constructor(props){
    super(props);

  }

  render(){
    let app = this.props.app
    let pic = this.props.app.state.user.components;
    let run = app.run;
  return (
    <div>
      {pic.map((picture, index)=>
      <div>
        {picture.getJson().type==="keepmonsters" &&(
          <div key={index} style={{display:"flex", flexDirection:"row", justifyContent:"space-around"}}>
          <img style= {{width:"75px", height:"100px"}} src={picture.getJson().pic} /><div>{picture.getJson().name} <p 
          onClick={run.bind(this, {del: [picture]})}
          >delete</p></div> 
        </div>
        )}
        {picture.getJson().type==="keepstatblocks" &&(
          <div key={index} style={{display:"flex", flexDirection:"row", justifyContent:"space-around"}}>
          <img style= {{width:"75px", height:"100px"}} src={picture.getJson().pic} /><div>{picture.getJson().name} <p 
          // onClick={this.del.bind(this,"keepmonsters", monster)}
          >delete</p></div> 
        </div>
        )}
        {picture.getJson().type==="keepheroes" &&(
          <div key={index} style={{display:"flex", flexDirection:"row", justifyContent:"space-around"}}>
          <img style= {{width:"75px", height:"100px"}} src={picture.getJson().pic} /><div>{picture.getJson().name} <p 
          // onClick={this.del.bind(this,"keepmonsters", monster)}
          >delete</p></div> 
        </div>
        )}
  </div>
      )}
    </div>
  )}
}
//           {/* <Gallery state = {this.props.state} handlechange = {this.props.handlechange} /> */}