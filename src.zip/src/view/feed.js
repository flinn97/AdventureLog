import { Component } from 'react';
import "../App.css"
// import Gallery from './pictures';
import left from '../pics/leftarrow.png'
import right from '../pics/rightarrow.png'
import picservice from '../services/picservice';
import Beholder from "../pics/beholder.webp";

export default class Feed extends Component {
  constructor(props){
    super(props);

  }



  render(){
    let app=this.props.app;
    let dispatch= app.dispatch;
    let run = app.run;
    let factory= app.state.factory
    let switchcase = app.state.switchcase;
    let currentComponent = app.state.currentComponent;
  return (
         <div style={{flex:"display", flexDirection:"row", alignItems:"center",  justifyContent:"center"}}>
          <div
          onClick= {dispatch.bind(this, {operation: "cleanJsonPrepareRun", operate: "add" + switchcase, object:{type: switchcase, name: "beholder", pics: Beholder} })}

          >addPic</div>

          <div
          onClick= {dispatch.bind(this, {operation: "cleanPrepareRun", operate: "del" , object: currentComponent})}

          >delPic</div>
          <div
           onClick={currentComponent?.keep}
            
            
          
          

            >{app.state.pic?.getJson().keep} Keeps </div>
       <img style={{width:"25px", height:"25px", marginRight:"20px"}} onClick={this.getprevpic} src={left}/>
           <img className="picture" id="pic" src={app.state.pic?.getJson().pic} />
           <img 
           onClick={dispatch.bind(this, {pic:picservice.randomizepics(app.state.user?.components, app.state.switchcase), picChange:true})} 
            style={{width: "25px", height: "25px", marginLeft: "20px"}} src={right}/>
           </div>


  )}
}
//           {/* <Gallery state = {this.props.state} handlechange = {this.props.handlechange} /> */}
// update:[[app.state.pic, {keep: app.state.pic?.getJson().keep +1}]]}, true)