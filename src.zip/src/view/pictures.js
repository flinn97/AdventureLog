import { Component } from 'react';
import "../App.css"



export default class Gallery extends Component {
  constructor(props){
    super(props);
  }
  render(){
  return (

           <div class="picturegallery">
            <img id="beholder" class="gallerypic" src={this.props.state.beholder} onClick={this.props.handlechange.bind(this, "beholder")}/>
            <img id="kraken" class="gallerypic" src={this.props.state.kraken} onClick={this.props.handlechange.bind(this, "kraken")}/>
            <img  id="dragon" class="gallerypic" src={this.props.state.dragon} onClick={this.props.handlechange.bind(this, "dragon")}/>
            <img  id="celestial" class="gallerypic" src={this.props.state.celestial} onClick={this.props.handlechange.bind(this, "celestial")}/>
            <img  id="bongobongo" class="gallerypic" src={this.props.state.bongobongo} onClick={this.props.handlechange.bind(this, "bongobongo")}/>
            <img  id="mummy" class="gallerypic" src={this.props.state.mummy} onClick={this.props.handlechange.bind(this, "mummy")}/>

          </div>
  )}
}